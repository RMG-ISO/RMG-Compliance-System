﻿namespace RMG.ComplianceSystem
{
    public abstract class ComplianceSystemDomainTestBase : ComplianceSystemTestBase<ComplianceSystemDomainTestModule> 
    {

    }
}
