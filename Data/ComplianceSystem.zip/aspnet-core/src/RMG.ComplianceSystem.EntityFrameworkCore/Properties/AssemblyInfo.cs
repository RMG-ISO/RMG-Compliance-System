﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("RMG.ComplianceSystem.EntityFrameworkCore.Tests")]
