﻿namespace RMG.ComplianceSystem.Permissions
{
    public static class ComplianceSystemPermissions
    {
        public const string GroupName = "ComplianceSystem";

        //Add your own permission names. Example:
        //public const string MyPermission1 = GroupName + ".MyPermission1";
    }
}