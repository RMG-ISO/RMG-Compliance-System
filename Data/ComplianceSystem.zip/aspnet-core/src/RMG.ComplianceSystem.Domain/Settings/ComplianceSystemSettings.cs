﻿namespace RMG.ComplianceSystem.Settings
{
    public static class ComplianceSystemSettings
    {
        private const string Prefix = "ComplianceSystem";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}