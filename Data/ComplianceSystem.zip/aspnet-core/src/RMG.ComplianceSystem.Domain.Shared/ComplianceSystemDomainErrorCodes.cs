﻿namespace RMG.ComplianceSystem
{
    public static class ComplianceSystemDomainErrorCodes
    {
        /* You can add your business exception error codes here, as constants */
    }
}
