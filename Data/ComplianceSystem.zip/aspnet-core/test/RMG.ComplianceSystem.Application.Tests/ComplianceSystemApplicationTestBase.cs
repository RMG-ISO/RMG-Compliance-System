﻿namespace RMG.ComplianceSystem
{
    public abstract class ComplianceSystemApplicationTestBase : ComplianceSystemTestBase<ComplianceSystemApplicationTestModule> 
    {

    }
}
