﻿using Volo.Abp.Localization;

namespace RMG.ComplianceSystem.Localization
{
    [LocalizationResourceName("ComplianceSystem")]
    public class ComplianceSystemResource
    {

    }
}