﻿using Volo.Abp;

namespace RMG.ComplianceSystem.EntityFrameworkCore
{
    public abstract class ComplianceSystemEntityFrameworkCoreTestBase : ComplianceSystemTestBase<ComplianceSystemEntityFrameworkCoreTestModule> 
    {

    }
}
