﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("RMG.ComplianceSystem.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("RMG.ComplianceSystem.TestBase")]
